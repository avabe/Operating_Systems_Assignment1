//
// Created by ava on 25/03/19.
//

#include "types.h"
#include "user.h"
#include "fcntl.h"


int
main(int argc, char *argv[]){

    if(argc < 2 || argc>3 ) {
        printf(2, "Illegal argument number!\n");
        exit(-1);
    }
    switch(*argv[1]) {
        case '1':
            policy(1);
            break;
        case '2':
            policy(2);
            break;
        case '3':
            policy(3);
            break;
        default:
            printf(2, "illegal policy number\n");
            exit(-1);
    }


    exit(0);
}
